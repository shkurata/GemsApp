import { Injectable } from '@angular/core';
//import { BehaviorSubject } from 'rxjs/BehaviorSubject';
import { Edelsteen } from './edelsteen';
import { Http, Response, Headers, RequestOptions } from '@angular/http';
import { Observable } from "rxjs/Observable";
import "rxjs/add/operator/map";
import "rxjs/add/operator/catch";


@Injectable()

export class EdelsteenService {
  
  // private edelstenenSubject = new BehaviorSubject<Array<any>>([]);
  // edelstenen = this.edelstenenSubject.asObservable();

  constructor(private http: Http) { }

  // changeEdelstenen(edelstenen) {
  //   this.edelstenenSubject.next(edelstenen);
  // }  

  getEdelstenen():Observable<Edelsteen[]> {
    return this.http.get('http://localhost:3000/edel')
    .map((response: Response) => <Edelsteen[]>response.json())
  }

  addEdelsteen(body: Object) {
    let bodyString = JSON.stringify(body);
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    //headers.append('Access-Control-Allow-Origin','*');
    //headers.append('Access-Control-Allow-Headers','Content-Type');
    let options = new RequestOptions({ headers: headers });

    return this.http.post('http://localhost:3000/nieuwEdel', body, options)
      .map((res:Response) => res.json())
      .catch((error) => error)
  }

}







